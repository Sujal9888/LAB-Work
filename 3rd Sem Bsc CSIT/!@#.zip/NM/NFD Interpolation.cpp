#include <stdio.h>

int main() {
    int n, i, j;
    float x[20], y[20][20], xp, h, u, sum, term;

    printf("---Newton's Forward Difference Interpolation---\n");

    printf("\nEnter the number of data points: ");
    scanf("%d", &n);

    printf("\nEnter the values of x:\n");
    for (i = 0; i < n; i++) {
    	printf("x%d=",i);
        scanf("%f", &x[i]);
    }

    printf("\nEnter the values of y:\n");
    for (i = 0; i < n; i++) {
    	printf("f(x%d)=",i);
        scanf("%f", &y[i][0]);  
    }

    for (j = 1; j < n; j++) {
        for (i = 0; i < n - j; i++) {
            y[i][j] = y[i + 1][j - 1] - y[i][j - 1];
        }
    }

    printf("\nEnter the value of x to find f(x): ");
    scanf("%f", &xp);

    h = x[1] - x[0];
    u = (xp - x[0]) / h;

    sum = y[0][0];
    term = 1;

    for (i = 1; i < n; i++) {
        term = term * (u - (i - 1)) / i;
        sum = sum + term * y[0][i];  
    }

    printf("\nThe approximate value at x = %.3f is f(x) = %.3f\n", xp, sum);

    return 0;
}
