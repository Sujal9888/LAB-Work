/* Write a basic C Program to print out a constant value. Use gcc compiler to generate an LINUX executable
file.*/
#include<stdio.h>
int main(){
	const int Value=100;
	printf("Constant Value = %d\n",Value);
return 0;
}
