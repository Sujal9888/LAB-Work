/*Explore the behavior of fork while using threads.*/

#include<stdio.h>
#include<unistd.h>
#include<pthread.h>
#include<time.h>
#include<stdlib.h>

void *show(void *u){
	printf("From Thread...\n");
	printf("The PID of this Thread is %d.\n",getpid());
	return NULL;
}
int main(){
	int pid;
	pthread_t tid;
	time_t t;
	time(&t);
	printf("Date: %s\n", ctime(&t));
	pthread_create(&tid, NULL, &show, NULL);

	printf("Main Thread...\n");
	printf("The PID of main Thread is %d.\n", getpid());
	printf("The PID of parent of Main Thread is %d.\n", getppid());

	pid=fork();
	if(pid==0){
		printf("This is the child process with PID: %d\n", getpid());
		printf("The Parent PID of this child is: %d\n", getppid());
		exit(0);
	}
	pthread_join(tid,NULL);
	return 0;
}
