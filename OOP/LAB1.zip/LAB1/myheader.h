// myheader.h
#include <iostream>



void greet() {
    std::cout << "Greetings from myheader.h!" << std::endl;
}

int add(int a, int b) {
    return a + b;
}
